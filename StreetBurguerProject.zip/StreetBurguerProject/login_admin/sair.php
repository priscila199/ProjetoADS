<?php

    session_start();

    unset($_SESSION['usuario']);
    unset($_SESSION['email']);

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8">
    <title>StreetBurguerProject - Login Admin</title>
    <link rel="shortcut icon" href="cc10aa0b80217891d077dd25327c6597.png">
    <link href='https://fonts.googleapis.com/css?family=Fredoka One' rel='stylesheet'>
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
</head>
<body>
	<img src="cc10aa0b80217891d077dd25327c6597.png" class="burger">
	<h3 class="login">FAÇA LOGIN NOVAMENTE</h3>
	<img src="logo.png" class="bb">

    <a href="index.php"><button type="buttom" class="botao" id="btn_login">Página Inicial</button></a>
    <br><br>

</form>

</body>
</html>
